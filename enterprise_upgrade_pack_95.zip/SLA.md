# SLA Model
- Availability: 99.5%
- Incident response: < 30 minutes
- Recovery time objective (RTO): 15 minutes
- Error budget: 0.5%
