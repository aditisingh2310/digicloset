from fastapi import FastAPI, HTTPException, Depends
from jose import jwt, JWTError
import time

app = FastAPI()
SECRET = "CHANGE_ME"

def verify_token(token: str):
    try:
        return jwt.decode(token, SECRET, algorithms=["HS256"])
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

@app.get("/auth/check")
def check(token: str):
    return verify_token(token)
