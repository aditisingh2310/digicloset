# Error Budget Policy
- Monthly error budget burn > 50% triggers freeze
- Automated rollback on 3 consecutive failed deploys
