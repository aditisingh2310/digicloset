# Zero-Trust Security Policy
- Mandatory JWT + mTLS between services
- Identity enforced at gateway level
- Every request authenticated + authorized
- No implicit trust for internal traffic
