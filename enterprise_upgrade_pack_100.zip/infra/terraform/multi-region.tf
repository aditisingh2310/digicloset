provider "aws" {
  region = "us-east-1"
}
module "replica_region" {
  source = "./modules/replica"
  region = "us-west-2"
}
