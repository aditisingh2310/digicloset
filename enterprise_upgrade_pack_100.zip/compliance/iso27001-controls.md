# ISO 27001 Mapping
- A.5: Information Security Policies ✅
- A.8: Asset Management ✅
- A.12: Operations Security ✅
- A.17: Business Continuity ✅
